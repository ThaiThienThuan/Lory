import 'package:flutter/material.dart';
import 'package:lory/utils/time_utils.dart';
import '../models/manga.dart';

class SearchResultsScreen extends StatefulWidget {
  final String searchQuery;
  final List<Manga> allManga;

  const SearchResultsScreen({
    required this.searchQuery,
    required this.allManga,
  });

  @override
  _SearchResultsScreenState createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  late TextEditingController _searchController;
  late List<Manga> _filteredManga;
  final ScrollController _scrollController = ScrollController();
  int _displayedMangaCount = 12;

  // ✅ THÊM: Filter states
  String _searchType = 'title'; // 'title', 'author', 'all'
  String? _selectedGenre; // null = All genres
  String _sortBy = 'relevance'; // 'relevance', 'rating', 'views', 'latest'

  // ✅ THÊM: Genre list (không dùng mock_data)
  final List<String> _availableGenres = [
    'Action',
    'Romance',
    'Comedy',
    'Fantasy',
    'Slice of Life',
    'Horror',
    'Sci-Fi',
    'Mystery',
    'Drama',
    'Adventure',
    'Manga',
    'Manhwa',
    'Manhua',
    'Martial Arts',
    'Magic',
    'Thriller',
    'Friendship',
  ];

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController(text: widget.searchQuery);
    _filteredManga = _filterManga(widget.searchQuery);
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ✅ UPDATED: Advanced filter logic
  List<Manga> _filterManga(String query) {
    List<Manga> results = widget.allManga;

    // Filter by search query
    if (query.isNotEmpty) {
      final lowerQuery = query.toLowerCase().trim();

      results = results.where((manga) {
        switch (_searchType) {
          case 'title':
            return manga.title.toLowerCase().contains(lowerQuery);
          case 'author':
            return manga.author.toLowerCase().contains(lowerQuery);
          case 'all':
          default:
            return manga.title.toLowerCase().contains(lowerQuery) ||
                manga.author.toLowerCase().contains(lowerQuery);
        }
      }).toList();
    }

    // Filter by genre
    if (_selectedGenre != null) {
      results = results.where((manga) {
        return manga.genres.contains(_selectedGenre);
      }).toList();
    }

    // Sort results
    switch (_sortBy) {
      case 'rating':
        results.sort((a, b) => b.rating.compareTo(a.rating));
        break;
      case 'views':
        results.sort((a, b) => b.views.compareTo(a.views));
        break;
      case 'latest':
        // Sort by newest manga (if you have createdAt field)
        // results.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case 'relevance':
      default:
        // Keep original order
        break;
    }

    return results;
  }

  void _onSearchChanged(String query) {
    setState(() {
      _filteredManga = _filterManga(query);
      _displayedMangaCount = 12;
    });
  }

  void _onFilterChanged() {
    setState(() {
      _filteredManga = _filterManga(_searchController.text);
      _displayedMangaCount = 12;
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      if (_displayedMangaCount < _filteredManga.length) {
        setState(() {
          _displayedMangaCount =
              (_displayedMangaCount + 12).clamp(0, _filteredManga.length);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Theme.of(context).iconTheme.color,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Tìm Kiếm Nâng Cao',
          style: TextStyle(
            color: Theme.of(context).textTheme.titleLarge?.color,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          // ✅ Search input
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              onChanged: _onSearchChanged,
              style: TextStyle(
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
              decoration: InputDecoration(
                hintText: _searchType == 'title'
                    ? 'Tìm theo tên truyện...'
                    : _searchType == 'author'
                        ? 'Tìm theo tác giả...'
                        : 'Tìm kiếm...',
                hintStyle: TextStyle(
                  color: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.color
                      ?.withOpacity(0.4),
                ),
                prefixIcon: Icon(Icons.search, color: Color(0xFF06b6d4)),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(
                          Icons.clear,
                          color: Theme.of(context)
                              .iconTheme
                              .color
                              ?.withOpacity(0.5),
                        ),
                        onPressed: () {
                          _searchController.clear();
                          _onSearchChanged('');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Theme.of(context).cardTheme.color,
              ),
            ),
          ),

          // ✅ Filter chips row
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                // Search type filter
                _buildFilterChip(
                  label: 'Tiêu đề',
                  selected: _searchType == 'title',
                  onTap: () {
                    setState(() {
                      _searchType = 'title';
                      _onFilterChanged();
                    });
                  },
                ),
                SizedBox(width: 8),
                _buildFilterChip(
                  label: 'Tác giả',
                  selected: _searchType == 'author',
                  onTap: () {
                    setState(() {
                      _searchType = 'author';
                      _onFilterChanged();
                    });
                  },
                ),
                SizedBox(width: 8),
                _buildFilterChip(
                  label: 'Tất cả',
                  selected: _searchType == 'all',
                  onTap: () {
                    setState(() {
                      _searchType = 'all';
                      _onFilterChanged();
                    });
                  },
                ),
              ],
            ),
          ),

          SizedBox(height: 12),

          // ✅ Genre dropdown & Sort
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                // Genre dropdown
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardTheme.color,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _selectedGenre != null
                            ? Color(0xFF06b6d4)
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String?>(
                        value: _selectedGenre,
                        isExpanded: true,
                        hint: Row(
                          children: [
                            Icon(Icons.category,
                                size: 18, color: Color(0xFF06b6d4)),
                            SizedBox(width: 8),
                            Text(
                              'Thể loại',
                              style: TextStyle(
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.color,
                              ),
                            ),
                          ],
                        ),
                        items: [
                          DropdownMenuItem(
                            value: null,
                            child: Text('Tất cả thể loại'),
                          ),
                          ..._availableGenres.map((genre) {
                            return DropdownMenuItem(
                              value: genre,
                              child: Text(genre),
                            );
                          }).toList(),
                        ],
                        onChanged: (value) {
                          setState(() {
                            _selectedGenre = value;
                            _onFilterChanged();
                          });
                        },
                      ),
                    ),
                  ),
                ),

                SizedBox(width: 12),

                // Sort button
                Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardTheme.color,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: PopupMenuButton<String>(
                    icon: Icon(Icons.sort, color: Color(0xFF06b6d4)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    onSelected: (value) {
                      setState(() {
                        _sortBy = value;
                        _onFilterChanged();
                      });
                    },
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        value: 'relevance',
                        child: Row(
                          children: [
                            Icon(
                              Icons.star,
                              size: 18,
                              color: _sortBy == 'relevance'
                                  ? Color(0xFF06b6d4)
                                  : Theme.of(context).iconTheme.color,
                            ),
                            SizedBox(width: 12),
                            Text('Liên quan'),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        value: 'rating',
                        child: Row(
                          children: [
                            Icon(
                              Icons.star_rate,
                              size: 18,
                              color: _sortBy == 'rating'
                                  ? Color(0xFF06b6d4)
                                  : Theme.of(context).iconTheme.color,
                            ),
                            SizedBox(width: 12),
                            Text('Đánh giá cao'),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        value: 'views',
                        child: Row(
                          children: [
                            Icon(
                              Icons.trending_up,
                              size: 18,
                              color: _sortBy == 'views'
                                  ? Color(0xFF06b6d4)
                                  : Theme.of(context).iconTheme.color,
                            ),
                            SizedBox(width: 12),
                            Text('Xem nhiều'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 12),

          // ✅ Result count
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Text(
                  'Tìm thấy ${_filteredManga.length} kết quả',
                  style: TextStyle(
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                if (_selectedGenre != null) ...[
                  Text(' • ', style: TextStyle(color: Colors.grey)),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Color(0xFF06b6d4).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _selectedGenre!,
                      style: TextStyle(
                        fontSize: 12,
                        color: Color(0xFF06b6d4),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),

          // ✅ Grid results
          Expanded(
            child: _filteredManga.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.search_off,
                          size: 64,
                          color: Color(0xFF06b6d4).withOpacity(0.5),
                        ),
                        SizedBox(height: 16),
                        Text(
                          'Không tìm thấy truyện nào',
                          style: TextStyle(
                            color: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.color
                                ?.withOpacity(0.7),
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Hãy thử tìm kiếm với từ khóa khác',
                          style: TextStyle(
                            color: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.color
                                ?.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : GridView.builder(
                    controller: _scrollController,
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.65,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemCount:
                        _displayedMangaCount.clamp(0, _filteredManga.length),
                    itemBuilder: (context, index) {
                      final manga = _filteredManga[index];
                      return _buildMangaCard(manga);
                    },
                  ),
          ),
          if (_displayedMangaCount < _filteredManga.length)
            Padding(
              padding: EdgeInsets.all(16),
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF06b6d4)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color:
              selected ? Color(0xFF06b6d4) : Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? Color(0xFF06b6d4) : Colors.transparent,
            width: 2,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected
                ? Colors.white
                : Theme.of(context).textTheme.bodyMedium?.color,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  // Keep existing _buildMangaCard() method
  Widget _buildMangaCard(Manga manga) {
    final isDark = Theme.of(context).brightness == Brightness.dark; // ✅ Thêm

    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          '/detail',
          arguments: manga,
        );
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Theme.of(context).cardTheme.color, // ✅ Sửa
          boxShadow: [
            BoxShadow(
              color: (isDark ? Colors.black : Colors.grey)
                  .withOpacity(0.3), // ✅ Sửa
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.network(
                      manga.coverImage,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Container(
                          color: Theme.of(context).cardTheme.color, // ✅ Sửa
                          child: Center(
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  Color(0xFF06b6d4)),
                            ),
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: Theme.of(context).cardTheme.color, // ✅ Sửa
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.image_outlined,
                                size: 48,
                                color: Color(0xFF06b6d4).withOpacity(0.5),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Manga Cover',
                                style: TextStyle(
                                  color: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.color
                                      ?.withOpacity(0.5), // ✅ Sửa
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  if (manga.chapters.isNotEmpty)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFF06b6d4),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          TimeUtils.formatFromString(
                              manga.chapters.first.releaseDate),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    manga.title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color:
                          Theme.of(context).textTheme.bodyLarge?.color, // ✅ Sửa
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        Icons.star,
                        size: 12,
                        color: Color(0xFFfbbf24),
                      ),
                      SizedBox(width: 4),
                      Text(
                        manga.rating.toStringAsFixed(1),
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.color
                              ?.withOpacity(0.7), // ✅ Sửa
                        ),
                      ),
                      Spacer(),
                      Icon(
                        Icons.visibility,
                        size: 12,
                        color: Theme.of(context)
                            .iconTheme
                            .color
                            ?.withOpacity(0.5), // ✅ Sửa
                      ),
                      SizedBox(width: 4),
                      Text(
                        '${manga.views ~/ 1000}K',
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.color
                              ?.withOpacity(0.7), // ✅ Sửa
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Wrap(
                    spacing: 4,
                    children: manga.genres.take(2).map((genre) {
                      return Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Color(0xFFec4899).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          genre,
                          style: TextStyle(
                            fontSize: 9,
                            color: Color(0xFFec4899),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
